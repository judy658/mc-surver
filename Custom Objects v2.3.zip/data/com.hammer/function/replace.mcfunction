execute if predicate com.hammer:mainhand/hammers_can_upgrade run item modify entity @s weapon.mainhand com.hammer:upgrade_netherite
execute if predicate com.hammer:player_cursor/hammers_can_upgrade run item modify entity @s player.cursor com.hammer:upgrade_netherite
