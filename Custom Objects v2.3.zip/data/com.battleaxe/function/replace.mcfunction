execute if predicate com.battleaxe:mainhand/battleaxes_can_upgrade run item modify entity @s weapon.mainhand com.battleaxe:upgrade_netherite
execute if predicate com.battleaxe:player_cursor/battleaxes_can_upgrade run item modify entity @s player.cursor com.battleaxe:upgrade_netherite
