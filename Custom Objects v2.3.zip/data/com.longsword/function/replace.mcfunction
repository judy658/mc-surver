execute if predicate com.longsword:mainhand/long_swords_can_upgrade run item modify entity @s weapon.mainhand com.longsword:upgrade_netherite
execute if predicate com.longsword:player_cursor/long_swords_can_upgrade run item modify entity @s player.cursor com.longsword:upgrade_netherite
