execute if predicate com.club:mainhand/clubs_can_upgrade run item modify entity @s weapon.mainhand com.club:upgrade_netherite
execute if predicate com.club:player_cursor/clubs_can_upgrade run item modify entity @s player.cursor com.club:upgrade_netherite
