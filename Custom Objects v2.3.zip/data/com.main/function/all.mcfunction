execute as @a at @s run function com.battleaxe:replace
execute as @a at @s run function com.dagger:replace
execute as @a at @s run function com.hammer:replace
execute as @a at @s run function com.longsword:replace
execute as @a at @s run function com.hatchet:replace
execute as @a at @s run function com.throwable_things:boom