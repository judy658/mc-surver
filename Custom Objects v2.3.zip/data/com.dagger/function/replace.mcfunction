execute if predicate com.dagger:mainhand/shortswords_can_upgrade run item modify entity @s weapon.mainhand com.dagger:upgrade_netherite
execute if predicate com.dagger:player_cursor/shortswords_can_upgrade run item modify entity @s player.cursor com.dagger:upgrade_netherite
