execute if predicate com.hatchet:mainhand/hatchets_can_upgrade run item modify entity @s weapon.mainhand com.hatchet:upgrade_netherite
execute if predicate com.hatchet:player_cursor/hatchets_can_upgrade run item modify entity @s player.cursor com.hatchet:upgrade_netherite
